$('.menu').on('click',function(){
    $('.submenu').animate({'left' : '0'})
});

$('.close').on('click',function(){
    $('.submenu').animate({'left' : '-40%'})
})



